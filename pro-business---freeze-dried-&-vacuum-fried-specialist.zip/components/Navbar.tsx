
import React from 'react';

interface NavbarProps {
  cartCount: number;
  onCartClick: () => void;
  onAiClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ cartCount, onCartClick, onAiClick }) => {
  return (
    <nav className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-200 py-4 shadow-sm">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="bg-emerald-600 text-white p-2 rounded-lg font-bold text-xl">PB</div>
          <span className="text-2xl font-bold bg-gradient-to-r from-emerald-700 to-green-500 bg-clip-text text-transparent">Pro Business</span>
        </div>
        
        <div className="hidden md:flex gap-8 text-gray-600 font-semibold">
          <a href="#" className="hover:text-emerald-600 transition">الرئيسية</a>
          <a href="#shop" className="hover:text-emerald-600 transition">المتجر</a>
          <a href="#about" className="hover:text-emerald-600 transition">عن المصنع</a>
          <a href="#contact" className="hover:text-emerald-600 transition">اتصل بنا</a>
        </div>

        <div className="flex gap-4 items-center">
          <button 
            onClick={onAiClick}
            className="hidden sm:flex items-center gap-2 bg-indigo-50 text-indigo-700 px-4 py-2 rounded-full hover:bg-indigo-100 transition border border-indigo-200"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
            اسأل الذكاء الاصطناعي
          </button>
          
          <button 
            onClick={onCartClick}
            className="relative p-2 text-gray-600 hover:text-emerald-600 transition"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </nav>
  );
};
